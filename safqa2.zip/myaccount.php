<?php
include "inc/header.php";
?>
    <section class="bread">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Library</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Data</li>
                </ol>
            </nav>
        </div>
    </section>
    <section>

        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-4 col-12">
                    <div class="dashmenu">
                        <ul class="list-unstyled">
                            <li><a href="">dashboard</a></li>
                            <li><a href="">orders</a></li>
                            <li><a href="">downloads</a></li>
                            <li><a href="">addresses</a></li>
                            <li><a href="">my waller</a></li>
                            <li><a href="">account details</a></li>
                            <li><a href="">refund requests</a></li>
                            <li><a href="">discount point</a></li>
                            <li><a href="">logout</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-9 col-lg-9 col-sm-8 col-12">
                    <div class="dashcontent">

                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php
include "inc/footer.php";
?>