

//     // init cubeportfolio
//     $('#js-grid-lightbox-gallery').cubeportfolio({
//         filters: '#js-filters-lightbox-gallery1, #js-filters-lightbox-gallery2',
//         loadMore: '#js-loadMore-lightbox-gallery',
//         loadMoreAction: 'click',
//         layoutMode: 'grid',
//         mediaQueries: [{
//             width: 1500,
//             cols: 5
//         }, {
//             width: 1100,
//             cols: 4
//         }, {
//             width: 800,
//             cols: 3
//         }, {
//             width: 480,
//             cols: 2
//         }, {
//             width: 320,
//             cols: 1
//         }],
//         defaultFilter: '*',
//         animationType: 'rotateSides',
//         gapHorizontal: 10,
//         gapVertical: 10,
//         gridAdjustment: 'responsive',
//         caption: 'zoom',
//         displayType: 'sequentially',
//         displayTypeSpeed: 100,

//         // lightbox
//         lightboxDelegate: '.cbp-lightbox',
//         lightboxGallery: true,
//         lightboxTitleSrc: 'data-title',
//         lightboxCounter: '<div class="cbp-popup-lightbox-counter">{{current}} of {{total}}</div>',

//         // singlePageInline
//         singlePageInlineDelegate: '.cbp-singlePageInline',
//         singlePageInlinePosition: 'below',
//         singlePageInlineInFocus: true,
//         singlePageInlineCallback: function(element) {
//             // to update singlePageInline content use the following method: this.updateSinglePageInline(yourContent)
//             var t = this;
//             t.updateSinglePageInline();
         
//         },
//     });

//   var block = `<div class="cbp-l-inline">
//             <div class="cbp-l-inline-left">       
//                <img width="341" height="226" src="http://medical.eplug-ins.com/wp-content/uploads/2016/02/doctor-v-nurse-704.jpg" class="attachment-large size-large wp-post-image" alt="" srcset="http://medical.eplug-ins.com/wp-content/uploads/2016/02/doctor-v-nurse-704.jpg 341w, http://medical.eplug-ins.com/wp-content/uploads/2016/02/doctor-v-nurse-704-300x199.jpg 300w" sizes="(max-width: 341px) 100vw, 341px">    </div>
        
//             <div class="cbp-l-inline-right">
//                 <div class="cbp-l-inline-title">Dr. Keri Peterson MD</div>
//                 <div class="cbp-l-inline-subtitle">Cardiology</div>      
//                                   <div class="stars" style="z-index: 99;position: relative;">
//                           <i class="fa fa-star"></i>
//                           <i class="fa fa-star"></i>
//                           <i class="fa fa-star"></i>
//                           <i class="fa fa-star"></i>
//                           <i class="fa fa-star"></i>
//                           <span>(7)</span>
//                           </div>
        
//                 <div class="cbp-l-inline-desc">
//                     Dr. Steven Leon is a neurosurgeon in East Patchogue, New York and is affiliated with multiple hospitals in the area, including Brookhaven Memorial Hospital Medical Center and Southside Hospital. He received his medical degree from Harvard Medical School and has been in practice for 21 years. He is one of 5 doctors at Brookhaven Memorial Hospital Medical Center and one of 9 at Southside Hospital who specialize in Neurological Surgery.				
//                 </div>
        
//                 <a href="http://medical.eplug-ins.com/doctor/dr-keri-peterson-md/" class="cbp-l-inline-view">MORE DETAIL</a>
//             </div>
//         </div>`;